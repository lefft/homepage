#########################################
# data-cleaning-plotting-summary.r    ### 
# tim leffel, nov23/2016              ###
# tjleffel@gmail.com                  ###
#########################################

#### LOAD DEPENDENCIES ########################################################
## === === === === === === === === === === === === === === === === === ===
# install these if you don't have them, with
# install.packages("<package-name>")
library("plyr")
library("dplyr")
library("ggplot2")

# objectives:
#   - read in data
#   - toss unnecessary info
#   - screen data
#   - reformat data how we want it
#   - save clean data + summary tables
#   - diagnostic plots


#### DATA WRANGLING ###########################################################
## === === === === === === === === === === === === === === === === === ===
# check out your directory, make sure files are accessible
dir("results")

cols <- c("time","ip","controller","itemNum","elementNum","condition","group",
          "wordNum","word","RT","response","newline","target")

dat <- read.csv("results-nov22.txt",
                 comment.char="#",header=FALSE, sep=",")
names(dat) <- cols
rm(cols)

keepers <- 
  c("ip","controller","condition","wordNum","word","RT","response","target")

dat <- dat[, keepers]

subjInfo <- droplevels(dat[dat$controller=="Form", keepers])
rm(keepers)
length(levels(subjInfo$ip)) # 55 subjs

# forgot to change language label in html
# check out what languages we have
levels(droplevels(subjInfo[subjInfo$wordNum=="age", ])$word)
langs <- c("Bosnian","Dutch","Georgian","Hindi","Russian",
           "english","English")
notEng <- langs[1:(length(langs)-2)]

# set wordNum to "language" for these vals
subjInfo$wordNum <- as.character(subjInfo$wordNum)
subjInfo[subjInfo$word %in% langs, ]$wordNum <- "language"
rm(langs)

# levels(droplevels(subjInfo[!(subjInfo$wordNum=="language" & subjInfo$word %in% notEng), ]$ip))
notEng <- filter(subjInfo, (wordNum=="language" & word %in% notEng))
notEng <- droplevels(notEng)
notEng <- levels(notEng[notEng$wordNum=="language", ]$ip)

subjInfo <- droplevels(subjInfo[!(subjInfo$ip %in% notEng), ])

# check that we just have nums for age
# levels(droplevels(subjInfo[subjInfo$wordNum=="age",]$word))

# get ages ready to join w trial results
age <- subjInfo[subjInfo$wordNum=="age", c("ip","word")]
names(age)[2] <- "age"
age$age <- as.numeric(as.character(age$age))

# remove the duplicate entry [DEAL W THIS GLOBALLY LATER]
# check out ip dupes
table(age$ip)
# dupe is 5b324d4107af023c968c9bb09eded2f2
# and others have extra rows (but not same age?)
dupes <- 
  c("5b324d4107af023c968c9bb09eded2f2","4454fedbe871f772f0c42a2a261a6938",
    "9e6257e3e34010d79b3f3263726132fd","a28bb77a3395e6393c3d97807ff654d5")

age <- age[!duplicated(age), ] # get rid of first dupe
age <- droplevels(age[!(age$ip %in% dupes), ]) # get rid of the rest

# deal w the rest of the subj info later

# get the trial results
dat <- droplevels(dat[dat$controller=="OnlineJudgment", ])

# eliminate dupes
dat <- droplevels(dat[!(dat$ip %in% dupes), ])
# eliminate non-english
dat <- droplevels(dat[!(dat$ip %in% notEng), ])
rm(dupes); rm(notEng)

# 46 subj after removing dupes completely (find better sol'n) + non-engl
length(levels(dat$ip)) 

# join w ages
dat <- left_join(x=dat, y=age, by="ip")
rm(age)
# DOUBLE CHECK WE'RE ALL GOOD HERE

# eliminate age <18
dat <- dat[dat$age >= 18, ]

# get trial/item info
trials <- read.csv("items-and-fillers-final.csv", sep="\t")

# join trial/item info w results
dat <- left_join(x=dat, y=trials, by=c("condition","target"))
rm(trials)

# recode responses + check distribution
dat$response <- as.factor(ifelse(dat$response=="F","word","nonword"))
table(dat$response, useNA="always") # 1315 yes, 1307 no

# check dist of RT's -- outliers skewing it
hist(dat$RT, plot=TRUE)

# eliminate all trials w RT <250 or >1500
dat <- dat[dat$RT %in% 250:1500, ]

# re-run hist -- now have nice normal dist
hist(dat$RT, plot=TRUE) 

# eliminate all trials w incorrect response
wConds <- c("cond_filler_rel_word","cond_filler_unr_word",
            "cond_rel_word","cond_unr_word")
nwConds <- c("cond_filler_nonword","cond_rel_nonword","cond_unr_nonword")

dat$correct <- ifelse(
  (dat$response=="word" & dat$condition %in% wConds) |
    (dat$response=="nonword" & dat$condition %in% nwConds), TRUE, FALSE
)
rm(wConds); rm(nwConds)
# cut frame to just correct
# 2233 / 2343  == 95.3% accuracy
dat <- dat[dat$correct==TRUE, ] 

# dist still pretty nice
hist(dat$RT, plot=TRUE) 


#### MAKE SOME PLOTS + LOOK AT CONDITION MEANS ETC ############################
## === === === === === === === === === === === === === === === === === ===

# look at reaction times -- means by condition
cMeans <- aggregate(RT ~ condition, FUN="mean", data=dat)
names(cMeans)[2] <- "rt_mean"
cSD <- aggregate(RT ~ condition, FUN="sd", data=dat)
names(cSD)[2] <- "rt_sd"
cMeans <- left_join(x=cMeans, y=cSD, by="condition")
cMeans
rm(cSD)
# save condition means
# write.csv(cMeans, "condition-means.csv", row.names=FALSE)

# set age bins
table(dat$age, useNA="always")
dat$age_group <- 
  ifelse(dat$age < 35, "18-34 years old", "35+ years old")

# eliminate unnecessary columns + rearrange
dat <- dat[, c("ip","age","age_group","item_id","condition",
               "prime","target","RT","response","correct")]

# save the cleaned data
# write.csv(dat, "results-nov22-clean.csv", row.names=FALSE)

# look at a scatterplot by condition [not very informative(?)]
# can also look at log w aes y=log(RT)
# can use full data to look at fillers

nofillz <- dat[!startsWith(as.character(dat$condition), "cond_filler"), ]
nofillz <- droplevels(nofillz)

nofillz$condition <- 
  factor(nofillz$condition,
         levels=c("cond_rel_nonword","cond_unr_nonword",
                  "cond_rel_word","cond_unr_word"))


# can check plot before restricting to 250:4000 to see outliers
# can also check before incorrect thrown out
ggplot(data=nofillz, aes(x=age, y=RT, shape=response)) + 
  geom_point(position=position_dodge(width=.5), size=.5) +
  facet_wrap(~condition)

# saved this one as "RT-scatterplot.pdf" as 4x6L
ggplot(data=nofillz, aes(x=age, y=RT, color=age_group, shape=age_group)) + 
  geom_point(position=position_dodge(width=.5), size=.5) +
  facet_wrap(~condition)


stats <- ddply(nofillz, c("age_group","condition"), summarise,
               n=length(RT),
               mean=mean(RT, na.rm=TRUE),
               sd=sd(RT, na.rm=TRUE))

# write.csv(stats, "by-age-condition-means.csv", row.names=FALSE)

subjStats <- ddply(nofillz, c("ip","condition"), summarise,
                   n=length(RT),
                   mean=mean(RT, na.rm=TRUE),
                   sd=sd(RT, na.rm=TRUE))
# write.csv(subjStats, "by-subject-condition-means.csv", row.names=FALSE)

itemStats <- ddply(nofillz, c("item_id","condition"), summarise,
                   n=length(RT),
                   mean=mean(RT, na.rm=TRUE),
                   sd=sd(RT, na.rm=TRUE))
# write.csv(itemStats, "by-item-means.csv", row.names=FALSE)


#### BACK OF ENVELOPE / SCRATCH AREA ##########################################
## === === === === === === === === === === === === === === === === === ===

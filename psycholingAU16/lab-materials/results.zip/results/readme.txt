by: tim leffel
contact: tjleffel@gmail.com
date: nov23/2016
#################################################################

this archive contains materials for the lab report component of 

LING/PSYC 27010: Psycholinguistics 
The University of Chicago

the files are

	>> "data-cleaning-plotting-summary.r", an R script that reads, cleans, summarizes, and plots the data from a lexical decision experiment 

	>> "RT-scatterplot.pdf", a plot of age against decision for every accurate response (age groups also distinguished by color/shape)

	>> "results-nov22-clean.csv", a cleaned up version of the data

	>> "condition-means.csv", a file specifying the overall mean RT's for each condition (only this one contains filler info)

	>> "by-age-condition-means.csv", a file specifying the mean RT for each condition for each age group

	>> "by-subject-condition-means.csv", a file specifying each subject's mean RT for each condition, averaged over items

	>> "by-item-means.csv", a file specifying the average RT for each item in each condition, averaged over subjects

	>> "results-nov22.txt", a text file containing the raw/messy results of the experiment in comma-delimited format (comment character #)

	>> "items-and-fillers-final.csv", a comma-delimited file containing information about each trial 

	>> "lab-report-instructions.pdf", an extra copy of the lab report instructions

	>> "readme.txt" (this file) 
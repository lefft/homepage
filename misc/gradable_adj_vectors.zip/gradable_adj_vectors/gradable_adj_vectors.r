###############################################################################
### VISUALIZE SIMILARITY BETWEEN RELATIVE AND ABSOLUTE GRADABLE ADJECTIVES ####
# 
# NOTE: functions defined here refer to global variables, so be very careful 
#       if you want to adapt them for other applications! 
###############################################################################


# --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
### 1. set up environment and read in reshaped word vectors -------------------

# attach a couple of packages 
library(ggplot2); library(dplyr)

# set a nicer plot theme 
theme_set(theme_minimal(12) + theme(
  legend.position="top", panel.grid.minor = element_blank(), 
  legend.title=element_blank(), legend.key=element_rect(size=rel(0.15)), 
  legend.key.size=unit(1, "lines"), axis.title=element_text(size=rel(0.85)), 
  axis.ticks=element_line(size=rel(0.5)), axis.line=element_line(size=rel(0.5))
))

# read in the word vector data 
dat <- read.csv("data/vecs_words_as_cols.csv", colClasses="numeric")





# --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
### 2. helper functions -------------------------------------------------------

# refer to a word's vector ("wv") with a string ("key")
wv <- function(word) dat[[word]]

# for A,B length n: sum from 1:n of Ai*Bi over product of root sums of squares 
cosine_similarity <- function(v1, v2){
  sum(v1*v2) / ((sqrt(sum(v1^2))) * (sqrt(sum(v2^2))))
}

# compare vecs by passing just the word keys 
compare_words <- function(w1, w2, f=cosine_similarity) f(wv(w1), wv(w2))


# --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
### 3. get a list of absolute and relative gradable adjectives ----------------

# NOTE: adjectives are from Leffel, Xiang, and Kennedy (2016), SALT proceedings
adjs <- list(
  abs = c(
    # minimum standard 
    c("open", "spotted", "bent", "curved", "striped"), 
    # maximum standard 
    c("flat", "empty", "full", "closed", "plain", "straight")),
  rel = c(
    # relative standard 
    "long", "short", "big","small","tall","thin","thick","wide","narrow")
)





# --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
### 4. functions for computing and plotting similarity between adjtypes -------

adjtype <- function(adj){
  # get the "type" of an adjective (relative or absolute)
  if (adj %in% adjs$abs) return("absolute") 
  if (adj %in% adjs$rel) return("relative") 
  return("other")
}

adjtype_diffs <- function(adj){
  # calculate mean similarity between `adj` and each adjective type 
  abs_adjs <- adjs$abs[adjs$abs != adj]
  rel_adjs <- adjs$rel[adjs$rel != adj]
  
  msim_abs <- mean(sapply(abs_adjs, function(abs) compare_words(adj, abs)))
  msim_rel <- mean(sapply(rel_adjs, function(rel) compare_words(adj, rel)))
  
  # return as one-row data frame, to be combined by `get_gradable_adj_diffs()`
  return(data_frame(adj=adj, adj_type=adjtype(adj), 
                    absolute=msim_abs, relative=msim_rel))
}

get_gradable_adj_diffs <- function(){
  # get the measures for every adjective in `adjs` 
  do.call("rbind", lapply(unlist(adjs), function(adj) adjtype_diffs(adj)))
}

plot_gradable_adj_vecs <- function(data){
  # plot the measures, with rel on x axis, abs on y axis. 
  # `data` should be the value of a call to `get_gradable_adj_diffs()`
  ggplot(data, aes(x=relative, y=absolute, color=adj_type, label=adj)) + 
    geom_point() + geom_label(show.legend=FALSE) + 
    labs(x="average similarity to relative adjectives", 
         y="average similarity to absolute adjectives", 
         color="adjective type", 
         title="relative and absolute gradable adjective meanings", 
         subtitle="represention of similarity with vector semantics", 
         caption="\n\nvectors compared with cosine similarity")
}





# --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
### 5. compute adjtype differences for each adj, plot them --------------------

# get all the mean differences (20 adjs x 2 adj types = 40 data points)
diffs <- get_gradable_adj_diffs()

# plot mean diff from relative on x, mean diff from absolute on y. 
# color-code the semantic class of each adjective. 
(diffs_plot <- plot_gradable_adj_vecs(diffs))

# save the plot as a pdf 
ggsave(filename="gradable_adj_plot.pdf", 
       plot=diffs_plot, width=7, height=5, units="in")





# --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
### 6. bonus function! (not used here) ----------------------------------------

# find closest vector to a word (can find closest in sample for quicker dev)
closest_word <- function(word, samples=NULL){
  vec <- wv(word)
  if (is.null(samples)){
    comp_words <- names(dat) 
  } else {
    comp_words <- sample(names(dat), size=samples)
  }
  closest <- 0
  closest_word <- ""
  for (w in comp_words){
    w_dist <- compare_words(word, w)
    if (w_dist > closest){
      closest <- w_dist
      closest_word <- w
      message("new closest: ", sprintf("%05f", w_dist), " (",closest_word,")")
    }
  }
  return(setNames(closest, closest_word))
}

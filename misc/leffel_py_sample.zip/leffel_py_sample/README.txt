
This folder contains code used to manage twitter streams persistently running on an AWS EC2 machine. It finds completed output files (json), detects completed files, and transfers completed ones to an S3 storage bucket. All major events are tracked in log files, examples of which are also included in this directory. 

Note that for this code to be useful, there will need to be live streams running, with output directed to files located in `json_dir` (see docstring in `run_stream_management.py`). 

Contents are listed below. 

Get in touch with Tim with any questions (tjleffel@gmail.com)




### source files 

	>> `run_stream_management.py` -- top-level script, scheduled to run every 15min by a crontab job 

	>> `manage_stream.py` -- function encapsulating stream management routine, called for each stream in the top-level script 

	>> `manage_stream_utils.py` -- modular bits and pieces used by `manage_stream()` 


### example log files 
	>> `stream_log_{politics,vaping}.log` -- example log files tracking active streams 

	>> `transfer_log_{politics,vaping.log}` -- example log files tracking file transfers from ec2 to s3 bucket 

	>> `runs.txt` -- example file listing every run of `run_stream_management.py` triggered by the cron job 



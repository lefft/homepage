#!/usr/bin/python3

"""
This module defines utility functions for keeping track of twitter stream 
output files. They're all called by either `manage_stream()` or in the 
top-level script `stream_transfer.py`. 

Major components:
  >> initialize_log_file(fname, streamname)
  >> log_current_data_state(json_dir, log_file, streamname, suffix='.json')
  >> check_for_completed_files(json_dir, log_file, streamname, suffix='.json')
  >> move_files_to_s3(json_dir, mgmt_dir, 
                      files, stream, s3_dest, delete_json=False)
  >> update_stream_log(json_dir, completed_files, streamname, log_file)
  >> file_status(fname, log_df)
  >> get_modified_datetime(filelist, value='both')

Quick convenience functions: 
  >> fts(timestamp) (timestamp to string-formatted time 'from timestamp')
  >> form (string, datetime format used throughout)
  >> mtime(file) (modified time of a file)
  >> now_fmt() (current system time in desired format)
"""


import os
import re
import sys
import time
import zipfile
import subprocess as shell
from datetime import datetime as dt
import pandas as pd

# alias some funcs w long/annoying names 
fts = dt.fromtimestamp
form = '%Y-%m-%d %H:%M:%S'
mtime = os.path.getmtime
now_fmt = (lambda: str(dt.now().strftime(form)))



def initialize_log_file(fname, streamname):
  """
  create a log file to keep track of stream output file sizes 
  
  @param fname: the desired name of the new log file (with extension)
  @param streamname: string that will appear in tracked output files 
  @return: string telling user whether file was created (used for side effects)
  """
  with open(fname, 'w+') as f:
    f.write('### stream log for `{}` created {}\n'.format(streamname,now_fmt()))
    f.write('### files will be moved to s3 bucket when no longer active\n')
    f.write('filename,' + 'file_size,' + 'file_mtime,' + 'row_added' + '\n') 
  
  return {True:'log `{}` created'.format(fname), 
          False:'log `{}` *not* created'.format(fname)}[os.path.exists(fname)]





def log_current_data_state(json_dir, log_file, streamname, suffix='.json'):
  """
  write file sizes and modified times to a log file 

  calls: `initialize_log_file()`, `get_modified_datetime()`
  
  @param json_dir: location of the stream output files 
  @param log_file: name with extension of the log file tracking the streams 
  @param streamname: string appearing in output files to be included in log
  @param suffix: extension of files to be tracked (always .json for this proj)
  
  @return: string telling user whether file was updated (used for side effects)
  """
  
  # the files that we will eventually move 
  files = [os.path.join(json_dir, file) 
            for file in os.listdir(json_dir) if (
                file.endswith(suffix) and file.startswith(streamname + '_'))]
  
  # if there are no files, or if there is no log file, initialize the log 
  if len(files) == 0 or not os.path.exists(log_file): 
    initialize_log_file(log_file, streamname)
  
  # when was the log file modified last? 
  log_mtime = mtime(log_file)
  
  # sizes and mtimes for the files (`value='both'` gives both date and time)
  file_sizes = [size for size in map(os.path.getsize, files)]
  file_mtimes = get_modified_datetime(filelist=files, value='both')
  
  # write a line to the log file, recording fname, size, mtime, and nowtime 
  with open(log_file, 'a') as f:
    skel = '{},{},{},{}\n'
    for i in range(len(files)):
      f.write(skel.format(files[i], file_sizes[i], file_mtimes[i], now_fmt()))
  
  # tell user if log file was updated during this call 
  if mtime(log_file) > log_mtime:
    return 'log file `{}` successfully updated'.format(log_file) 
  else: 
    return 'no updates made to `{}`'.format(log_file)





def check_for_completed_files(json_dir, log_file, streamname, suffix='.json'):
  """
  check for stream output files that are done being written to 
  
  calls: `file_status()`

  @param json_dir 
  @param log_file
  @param streamname string, identifier for stream (output file prefix)
  @param suffix extension of target files (always .json for this proj)
  """
  # read in the log file as a data frame 
  log_df = pd.read_csv(log_file, skiprows=2)
  
  # get filelist from the logfile df
  files_log = sorted(list(log_df.filename.unique()))
  
  ### TODO -- REVISIT: FILES_DIR USUALLY WILL NOT CONTAIN MOVED FILES!!!
  
  # get full filelist from the actual directory 
  files_dir = [*map(lambda f: os.path.join(json_dir, f), os.listdir(json_dir))]
  # subset to just the files with appropriate suffix and prefix (streamname)
  files_dir = sorted(list(filter(
    lambda f: f.endswith(suffix) and f.startswith(json_dir+streamname+'_'), 
    files_dir)))
  
  # number of relevant files in the directory 
  n_files = len(files_dir) 
  
  ### TODO -- CONSIDER CASE WHERE NEW FILE GETS CREATED BUT HASNT BEEN LOGGED 
  ### TODO -- BETTER HANDLING OF CASES WHERE SOMEONE MODIFIED A FILE MANUALLY
  
  # make sure all assumptions are satisfied 
  tests = [
    files_log == files_dir,                   # the filelists are equal 
    n_files is len(files_log),                # agree on number of files
    n_files is sum(map(lambda t: t[0]==t[1],  # all elements are pairwise equal
                       zip(files_log, files_dir)))]
  
  if sum(tests) < 3: 
    ### TODO -- improve error handling 
    # placeholder until better error handling is in place 
    print('      something went wrong -- the tests failed!\n')
    return []
  else: 
    files = files_log
  
  # get the status of each file, using fname as dict key 
  fstatus = dict(zip(files, map(lambda f: file_status(f, log_df), files)))
  
  # return filenames of completed output files 
  return [key for key,val in fstatus.items() if val=='complete']
  ##############################################################





def move_files_to_s3(json_dir, mgmt_dir, 
                     files, stream, s3_dest, delete_json=False):
  """
  zips up and moves completed files for a single stream 

  @param json_dir string, location of stream output files 
  @param mgmt_dir string, location of stream management code and logs 
  @param files list, filenames of files to be zipped up and moved 
  @param stream string, prefix of zip archive to be created 
  @param s3_dest string, destination folder on s3 for zip archive  
  @param delete_json boolean, delete local json files after transfer? 
  """
  
  print('  >> moving {} `{}` files to s3 bucket...\n'.format(len(files),stream))
  
  # filename of zip archive to be created 
  zipname = '{}_{}.zip'.format(stream, str(dt.now().strftime('%Y%m%d_%H%M%S')))
  
  # destination on s3 bucket 
  # [**SPECIFY BEFORE ATTACHING PATH TO zipname**]
  dest_file = os.path.join(s3_dest, zipname)
  
  # attach ec2 stream management path to zip filename 
  zipname = os.path.join(mgmt_dir, zipname)
  
  ### TODO -- check that there's no zip with the desired name 
  # assert not os.path.isfile(zipname), '{} already exists!'.format(zipname)
  
  # zip up all the files in `files_dir`, write as `zipname` 
  with zipfile.ZipFile(zipname, 'w') as z:
    for f in files:
      z.write(f)
  
  # copy `zipname` from current location to s3 bucket 
  shell.run(['aws', 's3', 'cp', zipname, dest_file])
  
  ### TODO -- BETTER MANAGEMENT OF DELETED JSON FILES 
  # need to check to see if S3 transfer was successful before delete files
  if delete_json==True: 
    print('***CAREFUL*** -- need to run test that files are indeed on s3')
    # remove all of the files we just zipped up and moved 
    for file in files:
      shell.run(['rm', file])
  
  # print a message 
  print('  >> moved `{}` stream files to s3 bucket location:\n     {}'.format(
    stream, dest_file))
  
  # dont return anything 





def update_stream_log(json_dir, completed_files, streamname, log_file):
  """
  update active output files log for a stream (remove completed files)
  
  @param json_dir location of stream files 
  @param completed_files list of files to remove from log 
  @param streamname prefix identifier for stream 
  @param log_file file to be modified   
  """
  
  print('updating log file for stream `{}`'.format(streamname))
  
  with open(log_file, 'r') as f:
    log_lines = f.readlines()
  
  n_lines = len(log_lines)
  
  lines_to_trash = []
  for fname in completed_files:
    for line_index in range(len(log_lines)):
      if re.match(re.sub('[^\\d\\w]', '', fname), 
                  re.sub('[^\\d\\w]', '', log_lines[line_index])):
        lines_to_trash.append(line_index)
  
  # filter out potential dupes and sort the line indices 
  lines_to_trash = [*set(lines_to_trash)]
  
  print('removing {} lines from `{}`'.format(len(lines_to_trash), log_file))
  
  # rewrite the file, omitting lines whose index is in trash list 
  with open(log_file, 'w') as f:
    for line_index in range(n_lines):
      if line_index not in lines_to_trash:
        f.write(log_lines[line_index])
  
  # dont return anything 






def file_status(fname, log_df):
  """
  function to check whether a file is done being updated 
  
  @param fname the name of a stream output file (.json)
  @param log_df a pandas df with file change info for stream files 
  @return boolean, True if file is done being updated, False if not 
  """
  # subset log file to the rows about fname 
  fname_rows = log_df[log_df.filename == fname]
  
  # get the two most recent mtimes and the two largest file sizes 
  mtimes = sorted(list(fname_rows.file_mtime), reverse=True)[0:2]
  sizes = sorted(list(fname_rows.file_size), reverse=True)[0:2]
  
  # if there's only one row, then the file is not done 
  if fname_rows.shape[0] < 2: 
    return 'active'
  
  # if two most recent mtimes *and* two biggest sizes are the same, we're done 
  if mtimes[0] == mtimes[1] and sizes[0] == sizes[1]:
    return 'complete' 
  # otherwise, we're not done yet 
  else:
    return 'active'



def get_modified_datetime(filelist, value='both'):
  """
  get the modified date and time of a list of files 
  
  @param filelist a list of filenames (with paths joined)
  @param value a string, either 'dates', 'times', or 'both'
  @return a list of strings with modified date/time/date-time for filelist
  """
  ### TODO -- shd be a warning/exception instead of 'no files' probably...
  if len(filelist) == 0: return 'no files'
  dts = [time for time in map(lambda x: fts(mtime(x)).strftime(form), filelist)]
  if value=='both': return dts
  else: return {'dates': list(map(lambda x: x.split(' ')[0], dts)), 
                'times': list(map(lambda x: x.split(' ')[1], dts))}[value]





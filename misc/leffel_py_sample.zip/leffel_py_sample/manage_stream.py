#!/usr/bin/python3

"""
This module defines the function `manage_stream()`. 

The function looks for json files no longer being written to by a tweepy stream 
('completed files'). If completed files are found, they are zipped up and 
transferred to an s3 storage bucket, and then removed from the ec2 stream 
output directory (if `rm_local` is `True`). 

Active stream output files are kept track of in the file named by `log_file`. 

Transfers from ec2 to s3 are logged in the file named by `completed_files_log`.
"""


from manage_stream_utils import * 


def manage_stream(streamname, json_dir, mgmt_dir, 
                  log_file, completed_files_log, s3_dest, rm_local):
  """
  manage stream output for a single stream 

  @param streamname string identifier of stream (output file prefix)
  @param json_dir location of the output files 
  @param mgmt_dir location of the stream management code (and log files)
  @param log_file file tracking active stream files 
  @param completed_files_log file tracking file transfers 
  @param rm_local boolean, remove local json files after transfer to s3?
  @param s3_dest string, destination for zip archives on s3 
  @return no return value, just used for side-effects 
  """
  # initialize log file if it doesn't exist 
  if not os.path.exists(log_file):
    initialize_log_file(fname=log_file, streamname=streamname)
  
  # 2 -- if no completed files log exists, initialize one 
  if not os.path.exists(completed_files_log):
    with open(completed_files_log, 'w') as f:
      f.write('# {}\n# {}\n# {}\n'.format(
        '[transfer log for `{}` -- created {}]'.format(streamname, now_fmt()),
        'files listed here have been moved to the s3 bucket', '~~~ '*15))
  
  # 3 -- log current data state 
  log_current_data_state(json_dir, log_file, streamname)
  
  # 4 -- check for completed files 
  completed_files = check_for_completed_files(json_dir, log_file, streamname)
  
  # 5/6/7 -- if there are completed files, ... 
  if len(completed_files) > 0:
    
    # 5 -- zip them up, move to s3 bucket, and print a message 
    #      [NOTE: MANAGEMENT PATH IS HARD-CODED IN MOVE FILES FUNC]
    move_files_to_s3(json_dir, mgmt_dir, completed_files, 
                     streamname, s3_dest, delete_json=rm_local)
    
    # 6 -- after theyre moved to s3, append fnames to completed files log 
    with open(completed_files_log, 'a') as f: 
      f.write('# [{} files added {}\n'.format(len(completed_files), now_fmt()))
      for fname in completed_files: 
        f.write('{} {}'.format(fname, '\n'))
    
    # 7 -- then remove logging info for completed files 
    update_stream_log(json_dir, completed_files, streamname, log_file)



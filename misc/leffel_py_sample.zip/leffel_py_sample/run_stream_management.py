#!/usr/bin/python3

"""
This is the top-level script that manages output files from tweepy streams, 
which will be running persistently on an ec2 machine. The goal is to identify 
completed stream files, and transfer them to an s3 storage bucket so that we 
don't run out of space on ec2. 

This script gets executed every 15min by a crontab job running on the ec2. 

For each element of `streams`, there should be output files in `json_dir` with 
a corresponding prefix. When `manage_stream()` is called, the statuses of all 
files beginning with `streamname` are logged. If any such files are completed, 
then they will be zipped up and moved to the s3 storage bucket. 

NOTE: 
  throughout the files in this directory, places where small improvements 
  should be made are marked with `### TODO -- `
"""

import os
from manage_stream import manage_stream
from manage_stream_utils import now_fmt


streams = ['politics', 'vaping']       # [FULL LIST SUPPRESSED]
json_dir = 'json'                      # [REAL LOCATION SUPPRESSED]
mgmt_dir = ''                          # [REAL LOCATION SUPPRESSED]




# check, transfer, and update each stream 
for streamname in streams:
  
  stream_log = os.path.join(mgmt_dir,'stream_log_{}.log'.format(streamname))
  transfer_log = os.path.join(mgmt_dir,'transfer_log_{}.log'.format(streamname))

  s3_dest = '<PATH-TO-STORAGE-DIR-ON-S3-BUCKET>' + streamname + '/'

  manage_stream(streamname, 
                json_dir, mgmt_dir, 
                stream_log, transfer_log, 
                s3_dest, rm_local=True)

  print('  >> managed stream `{}` at {}\n'.format(streamname, now_fmt()))


run_tracker = os.path.join(mgmt_dir, 'runs.txt')

if not os.path.exists(run_tracker):
  with open(run_tracker, 'w+') as tracker:
    tracker.write('### this file tracks stream management runs\n')
    tracker.write('### `run_stream_management.py` was run at these times:\n')
else:
  with open(run_tracker, 'a') as tracker:
    tracker.write(' >> {}\n'.format(now_fmt()))





